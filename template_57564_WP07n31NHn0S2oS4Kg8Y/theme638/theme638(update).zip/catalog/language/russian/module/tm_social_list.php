<?php
// Text
$_['text_heading'] = 'Присоединяйтесь';
