<?php
// Heading
$_['heading_title'] = 'Progress Bars';
