<?php
// Heading
$_['heading_title']    = 'Instagram';

// Text
$_['text_edit']        = 'Edit Account';
