<?php
// Heading
$_['heading_title'] = 'Cookie Policy';
$_['text_cookie_close']      = 'Close';